﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using Verse;

namespace Clockwork
{
 //   public class IntegratedResearchProjectDef : ResearchProjectDef
 //   {
	//	public List<ResearchProjectDef> integratedPrerequisites;
	//	public List<ResearchProjectDef> integratedRequiredByThis;

	//	public virtual void PostLoad()
	//	{
	//		IntegrateResearch();
	//	}

	//	public void IntegrateResearch()
	//	{
	//		if (ClockworkAndSteamSettings.integratedResearch)
	//		{
	//			Log.Warning(String.Join("\n", integratedPrerequisites));
	//			Log.Warning("Bool is true");
	//			if (prerequisites != null)
 //               {
	//				Log.Warning("It exists...");
	//			}
	//			prerequisites.AddRange(integratedPrerequisites);
	//			Log.Warning(String.Join("\n", prerequisites));
	//			//requiredByThis.Union(integratedRequiredByThis);
	//		}
	//	}
	//}
}
