﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse;

namespace Clockwork
{

    /*public class ThingDef_TeslaShot : ThingDef
    {
        public float AddHediffChance = 0.5f;
        public HediffDef HediffToAdd;

        public override void ResolveReferences()
        {
            HediffToAdd = HediffDefOf.Shocked;
        }
    }*/

}
